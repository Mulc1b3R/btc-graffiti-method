


                                                   How to "burn" data into the BTC Blockchain.
												   
		

   
                                           .........................................................


   
                                   A method for transmitting human readable messages via the BTC blockchain. 



   
  1. create txt message.(ASCII).
     eg; "i love you" (note;do not include speechmarks).
	 
  2. convert to hexadecimal.( result = 69 20 6C 6F 76 65 20 79 6F 75).

     Here;  https://www.rapidtables.com/convert/number/ascii-to-hex.html
	 
	 or use the ascii to hex web page provided , just drag and drop in browser

  3. take the resulting string of 20 integers and concatenate them. (Do not leave any white space , just run the numbers together in a sequence).	 
      e.g 69 20 6C 6F 76 65 20 79 6F 75 becomes 69206C6F766520796F75.
	  
  4. double the string ; ie , 69206C6F766520796F7569206C6F766520796F75 (the trick here is to use 40 digits,required to generate a "btc legacy address" , i.e 2*20 in this case).

  5. visit ; https://blockchain.info/q/hashtoaddress/69206C6F766520796F7569206C6F766520796F75    (notice our string of 40 digits placed after /hashtoaddress/ ).
             
			 just copy and paste in to browser url. 

  6. The resulting page will give you a BTC Wallet Address,thus;			 
   
   
    1AarnyMuzztd2nsw9KnPAhNJfRVypKJ8M8  (= "i love you" or "i love youi love you") 
	
  7. Check out the address with a search @ https://bitaps.com/  for wallet details to double check everything is in order.(see screenshot provided).

  8. Send btc to that address and the message will appear within the blockchain when your transaction is mined. (only use a very small amount, (dust),as the btc will be irredeemable).

  9. Read your message by searching the block in which it was mined.(search by block number).
  
  10. The blockchain is an immutable ledger, so the message is burned into the blockchain (as human readable data) , forever.
      The message is "timestamped" as part of the verification process by the "node" that mines the Tx , and stored by all blockchain nodes
	  accross the planet.
  
                                                 ...........................................................
												 
  Notes: 

        The number 20 acts as "whitespace" leaving a gap in between words,as with normal text.
		
		A BTC Address starting with the number 1 (as above) is commonly known as a "Legacy address" ,P2PKH .

		These legacy addresses are commonly used and widely accepted across various platforms.

        The text should be brief and to the point, the string must consist of 20-characters in order to convert to an actual btc address.
        (The hex code consists of "pairs" of numbers or "pairs" of numbers and letters,resulting in a string of numbers and letters with a length of 40 places).

        If the string is less than 40 it will return an error , you can make up the length using "whitespace" represented by the number 20,
        or random symbols such as @?!&*$<> e.t.c.

        It is possible to make the message as long as you like but with the price of BTC what it is as i write this,it would become prohibitively expensive

        for the average person.
		
	    The address is displayed in ASCII using a technique called Base58Check encoding. This ASCII address,(160 bit),

		such as 1AarnyMuzztd2nsw9KnPAhNJfRVypKJ8M8, is the address used for transferring Bitcoins.

		But inside the transaction, the address is stored as the 160-bit (20 byte) hex value. 

        Use cases can include any "milestone" in a persons life, e.g Birth of a child.Anniversary.proposal.birthday.valentines day.
		
        Data in a human readable form can be written to the chain in this way.
		
        It is even be possible to burn "code" into the blockchain , images , photographs , the Mona Lisa , a "Banksy" e.t.c.
		
		.....................................................................................................................................................

        The method for doing these things is more complicated and in some cases ,images for example , may be quite costly.
        Burning an image would require the image file (ping,jpg,etc) converting to base 64 data   as an initial step , and then
        turning the data in to "packets" consisting of strings of lenth40 ,then sending the data via a multicall transaction script.
		So that all the data is mined within the same block.(block time is approx 10 mins).
		
        Data could be encypted and transmitted in this manner,just using a laptop and wifi connection,and be "redeemable" by the intended
		
        recipient,almost instantly, anywhere in the world.		